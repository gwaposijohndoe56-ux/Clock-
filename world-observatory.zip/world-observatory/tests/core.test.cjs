const test = require('node:test');
const assert = require('node:assert/strict');
const core = require('../core.js');

test('IANA timezone offsets include half-hour and quarter-hour zones', () => {
  const instant = Date.parse('2026-01-15T12:00:00Z');
  assert.equal(core.offsetLabel(instant, 'Asia/Kathmandu'), 'UTC +05:45');
  assert.equal(core.offsetLabel(instant, 'Asia/Kolkata'), 'UTC +05:30');
  assert.equal(core.offsetLabel(instant, 'UTC'), 'UTC +00:00');
});

test('timezone rules change with the date for London and New York', () => {
  assert.equal(core.offsetLabel(Date.parse('2026-01-15T12:00:00Z'), 'Europe/London'), 'UTC +00:00');
  assert.equal(core.offsetLabel(Date.parse('2026-07-15T12:00:00Z'), 'Europe/London'), 'UTC +01:00');
  assert.equal(core.offsetLabel(Date.parse('2026-01-15T12:00:00Z'), 'America/New_York'), 'UTC -05:00');
  assert.equal(core.offsetLabel(Date.parse('2026-07-15T12:00:00Z'), 'America/New_York'), 'UTC -04:00');
});

test('formatting keeps city-local date independent from device timezone', () => {
  const beforeMidnightUtc = Date.parse('2026-01-01T15:30:00Z');
  assert.match(core.formatDate(beforeMidnightUtc, 'Asia/Tokyo'), /January 2, 2026/);
  assert.match(core.formatDate(beforeMidnightUtc, 'America/Los_Angeles'), /January 1, 2026/);
  assert.equal(core.formatClock(beforeMidnightUtc, 'Asia/Tokyo', { seconds: false, format: '24' }), '00:30');
  assert.equal(core.formatClock(beforeMidnightUtc, 'Asia/Tokyo', { seconds: false, format: '12' }), '12:30 AM');
});

test('elapsed countdown is derived from target time, not timer tick counts', () => {
  assert.equal(core.remainingUntil(10_000, 1_250), 8_750);
  assert.equal(core.remainingUntil(10_000, 10_001), 0);
  assert.equal(core.remainingUntil(1_000, 9_000), 0);
});

test('duration rendering handles minute, hour, completion, and centiseconds', () => {
  assert.equal(core.formatDuration(300_000), '05:00');
  assert.equal(core.formatDuration(3_661_000), '01:01:01');
  assert.equal(core.formatDuration(0), '00:00');
  assert.equal(core.formatDuration(12_349, { centis: true }), '00:12.34');
});

test('lap computation preserves cumulative total and split delta', () => {
  const first = core.calculateLap(12_340, 0, null);
  const second = core.calculateLap(21_800, 12_340, first.split);
  assert.deepEqual(first, { split: 12_340, total: 12_340, delta: null });
  assert.deepEqual(second, { split: 9_460, total: 21_800, delta: -2_880 });
});

test('solar position changes over a day and stays within geographic limits', () => {
  const morning = core.solarPosition(Date.parse('2026-06-21T06:00:00Z'));
  const evening = core.solarPosition(Date.parse('2026-06-21T18:00:00Z'));
  assert.ok(Math.abs(morning.lat) <= 24 && Math.abs(evening.lat) <= 24);
  assert.ok(morning.lng >= -180 && morning.lng < 180);
  assert.ok(evening.lng >= -180 && evening.lng < 180);
  assert.ok(Math.abs(morning.lng - evening.lng) > 170);
});


test('IANA zone.tab parser reads representative points and multiple country codes', () => {
  const sample = [
    '# comment line',
    'US\t+404251-0740023\tAmerica/New_York\tNew York City',
    'NP\t+2743+08519\tAsia/Kathmandu\tKathmandu',
    'US,CA\t+4916-12307\tAmerica/Vancouver\tVancouver',
    'bad\tcoordinates\tNot/AZone\tBroken'
  ].join('\n');
  const rows = core.parseZoneTab(sample);
  assert.equal(rows.length, 4);
  assert.deepEqual(rows[0], { cc: 'US', lat: 40 + 42/60 + 51/3600, lng: -(74 + 0/60 + 23/3600), tz: 'America/New_York', comment: 'New York City' });
  assert.deepEqual(rows[1], { cc: 'NP', lat: 27 + 43/60, lng: 85 + 19/60, tz: 'Asia/Kathmandu', comment: 'Kathmandu' });
  assert.equal(rows[2].cc, 'US');
  assert.equal(rows[3].cc, 'CA');
});
